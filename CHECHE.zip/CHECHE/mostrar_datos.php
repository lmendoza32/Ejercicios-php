<!DOCTYPE html>
<html>
<head>
	<title>HTML + CSS + JAVASCRIPT + PHP + MYSQL</title>
	<link rel="stylesheet" href="estilo_formulario.css">
</head>
<body>
	<ul>
		<li><a href="formulario_bdd.html">INSERT</a></li>
		<li><a href="mostrar_datos.php">SELECT</a></li>
		<li><a href="mostrar_datos.php">UPDATE</a></li>
		<li><a href="mostrar_datos.php">DELETE</a></li>
	</ul>
	<h1><center>Ingresando Datos a una BDD con PHP</center></h1>
	<h3>Los alumnos registrados son:</h3><br>
	<?php
		$conexion = mysqli_connect("localhost","root","administrador","escuela");
		$querySelect = "SELECT" * FROM alumnos ORDER BY nombre ASC";
		$resultado = mysqli_query($conexion, $querySelect);
	?>
	<table>
		<tr>
			<th>ID</th>
			<th>Nombre</th>
			<th>Paterno</th>
			<th>Materno</th>
			<th>Bachillerato</th>
			<th>Sexo</th>
		</tr>
		<?php
			while($alumnos=mysqli_fetch_array($resultado))
			{
				echo "
				<tr>
					<td>.$alumnos['id']</td>
					<td>.$alumnos['nombre']</td>
					<td>.$alumnos['apaterno']</td>
					<td>.$alumnos['amaterno']</td>
					<td>.$alumnos['bachillerato']</td>
					<td>.$alumnos['sexo']</td>
				</tr>
				";
			}
		?>
	</table>
</body>
</html>