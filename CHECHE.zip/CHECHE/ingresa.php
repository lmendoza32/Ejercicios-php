<!DOCTYPE html>
<html>
<head>
	<title>HTML + CSS + JAVASCRIPT + PHP +MYSQL</title>
	<link rel="stylesheet" href="estilo_formulario.css">
</head>
<body>
	<h1><center>Ingresando Datos a una BDD con PHP</center></h1>
	<h3>Los datos que se recibieron para procesarlos son:</h3><br>
	<span>Nombre(s): </span><?php echo $_POST['nombre']; ?><br>
	<span>Paterno: </span><?php echo $_POST['paterno']; ?><br>
	<span>Materno: </span><?php echo $_POST['materno']; ?><br>
	<span>Bachillerato: </span><?php echo $_POST['bachillerato']; ?><br>
	<span>Sexo: </span><?php echo $_POST['sexo']; ?><br>
	<?php
	$conexion = mysqli_connect("localhost","root","administrador","escuela");
	   $queryInsert = "INSERT INTO alumnos VALUES(
	                                       '#',
	   	                                   '".$_POST['nombre']."',
	   	                                   '".$_POST['paterno']."',
	   	                                   '".$_POST['materno']."',
	   	                                   '".$_POST['bachillerato']."',
	   	                                   '".$_POST['sexo']."'
	   	                                )";
	   mysqli_query($conexion, $queryInsert);
	?>
</body>
</html>